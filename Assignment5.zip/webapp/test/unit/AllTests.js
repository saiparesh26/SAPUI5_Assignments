sap.ui.define([
	"as/Assignment5/test/unit/controller/buttonEvent.controller"
], function () {
	"use strict";
});