/*global QUnit*/

sap.ui.define([
	"as/Assignment5/controller/buttonEvent.controller"
], function (Controller) {
	"use strict";

	QUnit.module("buttonEvent Controller");

	QUnit.test("I should test the buttonEvent controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});