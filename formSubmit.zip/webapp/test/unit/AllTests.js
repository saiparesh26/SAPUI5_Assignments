sap.ui.define([
	"ns/formSubmit/test/unit/controller/View1.controller"
], function () {
	"use strict";
});