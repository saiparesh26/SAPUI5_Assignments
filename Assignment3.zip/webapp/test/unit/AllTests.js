sap.ui.define([
	"a3/Assignment3/test/unit/controller/simpleForm.controller"
], function () {
	"use strict";
});