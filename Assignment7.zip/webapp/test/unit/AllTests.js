sap.ui.define([
	"as/Assignment7/test/unit/controller/table.controller"
], function () {
	"use strict";
});