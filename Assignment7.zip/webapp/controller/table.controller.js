sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("as.Assignment7.controller.table", {
		onInit: function () {
			var oData = {
				"names":[
					{
						Name:"Sai",
						Place:"Dehradun",
						Age:25
					},
					{
						Name:"Vandana",
						Place:"Orissa",
						Age:23
					},
					{
						Name:"Sanketh",
						Place:"Mumbai",
						Age:25
					}
					]
			};
			
			var oModel = new sap.ui.model.json.JSONModel(oData);
			oModel.setData(oData);
			this.getView().setModel(oModel);
			sap.ui.getCore().setModel(oModel);
		}
	});
});