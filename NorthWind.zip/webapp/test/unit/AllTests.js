sap.ui.define([
	"nw/NorthWind/test/unit/controller/View1.controller"
], function () {
	"use strict";
});