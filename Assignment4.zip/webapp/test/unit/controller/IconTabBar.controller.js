/*global QUnit*/

sap.ui.define([
	"as/Assignment4/controller/IconTabBar.controller"
], function (Controller) {
	"use strict";

	QUnit.module("IconTabBar Controller");

	QUnit.test("I should test the IconTabBar controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});