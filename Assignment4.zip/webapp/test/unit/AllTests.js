sap.ui.define([
	"as/Assignment4/test/unit/controller/IconTabBar.controller"
], function () {
	"use strict";
});