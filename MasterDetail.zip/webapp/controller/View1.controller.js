sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller,JSONModel) {
	"use strict";

	return Controller.extend("md.MasterDetail.controller.View1", {
		onInit: function () {
			var oEmpData = {
				"emp": [{
					"empid": "111111",
					"empname": "John Walter",
					"exp": "12",
					"age": "40",
					"city": "Tokyo",
					"country": "Japan",
					"designation": "Delivery Manager",
					"cadre": "Band 5",
					"projects": [{
						"projectid": "PGIMPL",
						"projectname": "P &amp; G SAP Implementation"
					}, {
						"projectid": "ARMSUPPORT",
						"projectname": "Aramco Support"
					}]
				}, {
					"empid": "222222",
					"empname": "Rashid Khan",
					"exp": "3",
					"age": "24",
					"city": "Tokyo",
					"country": "Japan",
					"cadre": "Band 1",
					"designation": "Software Engineer",
					"projects": [{
						"projectid": "AIRBNB",
						"projectname": "AIRBNB Implementation"
					}, {
						"projectid": "TATA",
						"projectname": "Tata Power Support"
					}]
				}, {
					"empid": "333333",
					"empname": "Supriya Singh",
					"exp": "5",
					"age": "34",
					"city": "Tokyo",
					"country": "Japan",
					"cadre": "Band 3",
					"designation": "Sr. Software Engineer",
					"projects": [{
						"projectid": "INDIAGOV",
						"projectname": "INDIA GOV SAP Implementation"
					}, {
						"projectid": "ARMSUPPORT",
						"projectname": "Aramco Support"
					}]
				}]
			};
			
			var oModel = new sap.ui.model.json.JSONModel(oEmpData);
			oModel.setData(oEmpData);
			this.getView().setModel(oModel);
			sap.ui.getCore().setModel(oModel );
		},
		
		onObjectItemPress: function (oEvent){
			
			var oItem = oEvent.getSource();
			var oCtx = oItem.getBindingContext();
			var path = oCtx.getPath();
			this.getView().byId("projectListId").bindElement(path);
		}
	});
});