/*global QUnit*/

sap.ui.define([
	"as/Assignment6/controller/buttonAndLabel.controller"
], function (Controller) {
	"use strict";

	QUnit.module("buttonAndLabel Controller");

	QUnit.test("I should test the buttonAndLabel controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});