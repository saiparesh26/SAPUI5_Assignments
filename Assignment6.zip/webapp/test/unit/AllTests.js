sap.ui.define([
	"as/Assignment6/test/unit/controller/buttonAndLabel.controller"
], function () {
	"use strict";
});