/*global QUnit*/

sap.ui.define([
	"md/MasterDetailSplitApp/controller/V_Root.controller"
], function (Controller) {
	"use strict";

	QUnit.module("V_Root Controller");

	QUnit.test("I should test the V_Root controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});