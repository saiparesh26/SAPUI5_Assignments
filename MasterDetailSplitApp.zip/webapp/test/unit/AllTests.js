sap.ui.define([
	"md/MasterDetailSplitApp/test/unit/controller/V_Root.controller"
], function () {
	"use strict";
});