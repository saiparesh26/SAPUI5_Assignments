sap.ui.define([
	"saip/splitappes5/SplitAppES5/test/unit/controller/V_Root.controller"
], function () {
	"use strict";
});