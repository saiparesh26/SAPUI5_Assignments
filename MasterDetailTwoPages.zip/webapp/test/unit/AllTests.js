sap.ui.define([
	"md/MasterDetailTwoPages/test/unit/controller/V_Root.controller"
], function () {
	"use strict";
});