sap.ui.define([
	"ns/Assignment2/test/unit/controller/employeeLogin.controller"
], function () {
	"use strict";
});